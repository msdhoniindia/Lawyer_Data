package com.lawyer.lawyers.Work;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LawyersWorkApplicationTests {

	@Test
	void contextLoads() {
	}

}
